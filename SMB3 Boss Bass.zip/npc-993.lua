local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")
local Bass = {}
local npcID = NPC_ID
local ASmovement = require("AI/bass")
local BassSettings = {
	id = npcID,
	iswaternpc=true,
	ChaseSpeed = 0.2,
	MaxSpeed = 6,
	JumpTimer = 5,
	MaxGravity = 5,
	maxJumps = 12,
	jumphurt = true,
	nohurt = false,
	gfxwidth=48,
	gfxheight=64,
	width=48,
	height=64,
	jumphurt=1,
	noblockcollision=1,
	nogravity=1,
	frames=2,
	framestyle=1,
	grid=64,
	gridoffsetx=0,
	effectID=754,
}

local configFile = npcManager.setNpcSettings(BassSettings)
npcManager.registerDefines(npcID,{NPC.UNHITTABLE})
function tablelength(T)
  local count = 0
  for _ in pairs(T) do count = count + 1 end
  return count
end
ASmovement.register(npcID)
return Bass